""" What is PostgreSQL ?
                   PostgreSQL is a advanced powerful open-sourse object-relational database managment system (ORDBMS) that uses and extends
                   the SQL language.

Where use PostgreSQL ?
                Web and Mobile application . 
                Data Warehousing and analytics.
                Store huge data base ML/AI .
                Geographic information system . 

What is the main feature in PostgreSQL ?
                id | name | age

Which language need for know PostgreSQL ?
                SQL (Sequal query langauge) is need to learn PostgreSQL.

Every ROW have a unique ID .

One table connect to another table . 



"""