groceries = {
    "milk: 10": 60,
    "Biscuits": 10,
    "Rice": 100,
    "Bread": 30
}

print(groceries["milk: 10"])

groceries = {"milk":60, #Dictionary never work with strate line . 
             "Biscuits":10,
             "Rice":100,
             "Bread":30}
groceries["eggs:"] = 10, # Dictionary are mutable so change are accepted, i hope you understand . 
 
print(list(groceries.values())[1])