"""
    How many different types of data represent here . 

    There are 4 main types of postgreSQL in here . 
    1. HIERARCHICAL DATABASE (Tree Structure)
             Data have Parent -> child shape
                     Usage:-  

                      Telephone directory 
                      Old systems
                      Telephone 
                      IBM main frame 

                      #Very old method , Now this system use very rare in industry . 

        

                      
    2. Relational Database (Most importent)
                      Data present in table and row column 

                      e.g., 
                          My SQL
                          PostgreSQL 
                          Oracle

                        Most use this 
    
    3. NoSQL Database (Big Data / AI )
                        Not required table 
                        JSON /Document/ Key-Value 
                        {
                          "name": "Rahul",
                          "age": 22
                        }

    4. Object-Oriented Database (OOP Based)

                       Data = object (Class + Data)
                       Example( Python style)

                       class student 
                             name
                             age

                usage :-
                Game
                Simulation 
                Scientific software

    5. Network Database (Graph Style)
                 So many relation connect togather . 
                 


                        


             
"""