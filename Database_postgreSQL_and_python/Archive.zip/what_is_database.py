"""
What is database ?
    Data base is like a digitalnotebook or cupboard where a information keep safely inside .

e.g., Your mobile :-
              |_ photo
              |_text
              |_book
              |_phone number every thing store inside in database .
"""

"""
Data base software name :-
Oracle
MongoDB etc...

Why use Data base ? 
  Data base is mandotory for several of resons and some i discusing now,
  so first one is , store the data , find the data, update the data, delete the data, keep data safe . 
  
"""